package products;

public class Pencil extends Product {
    private String color;

    public Pencil(int price, String color) {
        super(price);
        this.color = color;
    }

    public String getColor() {
        return color;
    }

    @Override
    public String toString(){
        return "products.Pencil: " +
                " Color = " + color +
                " Price = " + super.getPrice() + " Ft";
    }
}
