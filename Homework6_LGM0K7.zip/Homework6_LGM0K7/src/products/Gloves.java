package products;

public class Gloves extends Equipment {
    private String size;

    public Gloves(int securityLevel, String size) {
        super(securityLevel);
        this.size = size;
    }

    public String getSize() {
        return size;
    }

    @Override
    public String toString(){
        return "products.Gloves: " +
                "Size = " + size +
                " Security Level = " + getSecurityLevel();
    }
}
