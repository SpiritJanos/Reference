package products;

public class Mask extends Equipment {
    private String typeOfFixing;

    public Mask(int securityLevel, String typeOfFixing) {
        super(securityLevel);
        this.typeOfFixing = typeOfFixing;
    }

    public String getTypeOfFixing() {
        return typeOfFixing;
    }

    @Override
    public String toString(){
        return "products.Mask: " +
                "Type of Fixing = " + typeOfFixing +
                " Security Level = " + super.getSecurityLevel();
    }
}
