package products;

public class Notebook extends Product {
    private int pageNumber;

    public Notebook(int price, int pageNumber) {
        super(price);
        this.pageNumber = pageNumber;
    }

    public int getPageNumber() {
        return pageNumber;
    }

    @Override
    public String toString(){
        return "products.Notebook: " +
                "Page number = " + pageNumber +
                " Price = " + super.getPrice() + " Ft";
    }
}
