package products;

public class Equipment {
    private int securityLevel;

    public Equipment(int securityLevel) {
        this.securityLevel = securityLevel;
    }

    public int getSecurityLevel() {
        return securityLevel;
    }
}
