package box;

public class Box {
    private int id;
    private String type;
    private int numberOfItems;
    private String date;

    public Box(int id, String type, int numberOfItems, String date) {
        this.id = id;
        this.type = type;
        this.numberOfItems = numberOfItems;
        this.date = date;
    }

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public int getNumberOfItems() { return numberOfItems; }

    public void setNumberOfItems(int numberOfItems) { this.numberOfItems = numberOfItems; }

    public String getDate() { return date; }

    public void setDate(String date) { this.date = date; }

    public String getType() { return type; }

    public void setType(String type) { this.type = type; }

    @Override
    public String toString(){
        return "Box: [" + getId() +
                ", " + getType() +
                ", " + getNumberOfItems() +
                ", " + getDate() + "]";
    }

}
