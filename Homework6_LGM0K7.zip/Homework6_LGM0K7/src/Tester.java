import box.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Tester {
    private Scanner scanner = new Scanner(System.in);

    List<Box> boxes = new ArrayList<>();

    private int index = 0;

    public void start(){

        boxes.add(index, new Box(index, "Notebook", 30, "20120310"));
        index++;
        boxes.add(index, new Box(index, "Pencil", 20, "19980829"));
        index++;
        boxes.add(index, new Box(index, "Mask", 10, "19990915"));
        index++;
        boxes.add(index, new Box(index, "Gloves", 5, "20061107"));
        index++;
        boxes.add(index, new Box(index, "Notebook", 21, "20041224"));
        index++;
        boxes.add(index, new Box(index, "Pencil", 42, "19900301"));
        index++;
        boxes.add(index, new Box(index, "Mask", 53, "20200414"));
        index++;
        boxes.add(index, new Box(index, "Gloves", 34, "20180729"));
        index++;
        boxes.add(index, new Box(index, "Notebook", 11, "20181215"));
        index++;
        boxes.add(index, new Box(index, "Pencil", 14, "19951120"));
        index++;
        boxes.add(index, new Box(index, "Mask", 4, "20071008"));
        index++;
        boxes.add(index, new Box(index, "Gloves", 19, "20000101"));
        index++;

        String command;
        do {
            command = "";
            System.out.println("Storage:");
            System.out.println("1 - Add products and equipments to the products");
            System.out.println("2 - List the boxes");
            System.out.println("3 - Search for boxes");
            System.out.println("X - Quit");

            command = scanner.nextLine();
            switch (command){
                case "1": addBoxes();
                    break;
                case "2": listBoxes();
                    break;
                case "3":
                    System.out.println("Please give me the type of item you are looking for: ");
                    String type = scanner.next();
                    System.out.println("How much " + type + " you are looking for?");
                    int numberOfItems = scanner.nextInt();

                    List<Box> searchBoxes = searchBoxes(type, numberOfItems);

                            for (Box local : searchBoxes){
                                if (local instanceof Box){
                                    Box list = local;
                                    System.out.println(list);
                                }
                        }
                    break;
            }
        }while (command.compareTo("X") !=0);
    }


    public void addBoxes() {
        int index1;

        System.out.println("Please give the index of the box: ");
        index1 = scanner.nextInt();
        if (index1 != index){
            System.out.println("Please give me the product type you want to put in the box: ");
            String type = scanner.next();
            System.out.println("Please give me the amount of the items: ");
            int numberOfItems = scanner.nextInt();
            System.out.println("Please give me the date of production: ");
            String date = scanner.next();

            Box box = new Box(index1, type, numberOfItems, date);
            boxes.add(box);

        }else
            System.out.println("There is already a box with this index!");

    }
        public void listBoxes() {

            System.out.println("---------------------------------");

            boxes.forEach(System.out::println);

            System.out.println("---------------------------------");

        }

        public List<Box> searchBoxes(String type, int numberOfItems) {
            List<Box> newList = new ArrayList<>();


            if (type.equals("Notebook")) {
                for (Box local : boxes) {
                    if (local instanceof Box && local.getType().equals(type) && numberOfItems <= local.getNumberOfItems()) {
                        newList.add(local);
                    }
                } if (newList.isEmpty()) {
                    System.out.println("There was not any box eligible for this criterium!");
                }
            }
            if (type.equals("Pencil")) {
                for (Box local : boxes) {
                    if (local instanceof Box && local.getType().equals(type) && numberOfItems <= local.getNumberOfItems()) {
                        newList.add(local);
                    }
                } if (newList.isEmpty()) {
                    System.out.println("There was not any box eligible for this criterium!");
                }
            }
            if (type.equals("Mask")) {
                for (Box local : boxes) {
                    if (local instanceof Box && local.getType().equals(type) && numberOfItems <= local.getNumberOfItems()) {
                        newList.add(local);
                    }
                } if (newList.isEmpty()) {
                    System.out.println("There was not any box eligible for this criterium!");
                }
            }if (type.equals("Gloves")){
                for (Box local : boxes) {
                    if (local instanceof Box && local.getType().equals(type) && numberOfItems <= local.getNumberOfItems()) {
                        newList.add(local);
                    }
                }  if (newList.isEmpty()) {
                    System.out.println("There was not any box eligible for this criterium!");
                }
            }
            return newList;
        }
}
