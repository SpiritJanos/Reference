package edu.pte.mik.form;

//Interface to specify behaviors
//requested from out unique console based Forms
public interface Form {
    void show();
}
