package edu.pte.mik.model;

import edu.pte.mik.model.User;

import java.util.ArrayList;
import java.util.Scanner;

// A well known storage, using an ArrayList to store users, which is final not to change it
public class UserStorage {
    private final ArrayList<User> users = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    public int getUserCount() {
        return users.size();
    }

    public User getUser(int index) {
        if(index >= 0 && index < users.size()) {
            return users.get(index);
        }
        return null;
    }

    public void addUser(User newUser) throws AlreadyRegisteredException {
        for(User u : users) {
            if(u.getUserName().equalsIgnoreCase(newUser.getUserName())) {
                throw new AlreadyRegisteredException(newUser);
            }
        }
        users.add(newUser);
    }

    public void removeUser(int removeId, User user){
        for (User u: (ArrayList<User>) users.clone()){
            if (u.getId() == removeId){
                users.remove(u);
            }
        }
    }

    public void modifyFirstName(int modifyId, User user){
        for (User u : (ArrayList<User>) users.clone()) {
            if (u.getId() == modifyId){
                System.out.println("Please give me the new first name:");
                String newFirstName = scanner.nextLine();
                if (!newFirstName.isEmpty()) {
                    u.setFirstName(newFirstName);
                }else {
                    u.getFirstName();
                }
            }
        }
    }

    public void modifyLastName(int modifyId, User user){
        for (User u : (ArrayList<User>) users.clone()) {
            if (u.getId() == modifyId){
                System.out.println("Please give me the new last name:");
                String newLastName = scanner.nextLine();
                if (!newLastName.isEmpty()) {
                    u.setLastName(newLastName);
                }else {
                    u.getLastName();
                }
            }
        }
    }

    public void modifyIdentification(int modifyId, User user){
        for (User u : (ArrayList<User>) users.clone()) {
            if (u.getId() == modifyId){
                System.out.println("Please give me the new ID:");
                Integer newId = scanner.nextInt();
                if (newId != null) {
                    u.setId(newId);
                }else {
                    u.getId();
                }
            }
        }
    }

    public void modifyAge(int modifyId, User user){
        for (User u : (ArrayList<User>) users.clone()) {
            if (u.getId() == modifyId){
                System.out.println("Please give me the new age:");
                Integer newAge = scanner.nextInt();
                if (newAge != null) {
                    u.setAge(newAge);
                }else {
                    u.getAge();
                }
            }
        }
    }

    public void modifyPassword(int modifyId, User user){
        for (User u : (ArrayList<User>) users.clone()) {
            if (u.getId() == modifyId){
                System.out.println("Please give me the new password:");
                String newPassword = scanner.nextLine();
                if (!newPassword.isEmpty()) {
                    u.setPassword(newPassword);
                }else {
                    u.getPassword();
                }
            }
        }
    }

    // login method check if there is a user with specified user name and password (only hash stored)
    public boolean login(String userName, Password password) {
        for (User u : users) {
            if(u.getUserName().contentEquals(userName)
                    && u.getPassword().equalsTo(password)
            ) return true;
        }
        return false;
    }
}
