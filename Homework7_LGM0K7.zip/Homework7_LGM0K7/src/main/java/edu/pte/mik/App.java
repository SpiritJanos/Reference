package edu.pte.mik;

import edu.pte.mik.form.MainForm;

// A Maven project is created like it is specified in the lecture contents

public class App
{
    public static void main( String[] args )
    {
        // Creating the form controller
        // and pass the control
        new MainForm().show();
    }
}
