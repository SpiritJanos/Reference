package edu.pte.mik.reader;

// An interface to specify what a reader has to do
// (expected behaviors)
public interface IoReader {
    void get();
}
